sh -x 00_grant_priv_on_spatial.sh
read -p "Press enter to continue"
01_alter_locations_table.sql
read -p "Press enter to continue"
02_get_loc.sql
read -p "Press enter to continue"
03_distance_between.sql
read -p "Press enter to continue"
04_closest_airport.sql
read -p "Press enter to continue"
05_closest_BOS1.sql
echo "This didn't work.  We have non-airport locations in the table."
echo "Let's change this to only use sites with the fragment 'irport' in the name``
read -p "Press enter to continue"
06_closest_BOS2.sql
echo "This didn't work.  These airports are too small for a jetliner."
echo "Let's change this to only use sites in the otp_r table."
read -p "Press enter to continue"
07_closest_BOS3.sql
echo "That's more like it."
read -p "Press enter to continue"
08_distance_BOS_LAX.sql
echo ST_Distance can compute spheroid or two dimensional distances.  Which is more accurate?
read -p "Press enter to continue"

