create table pilots (
   name text,
   license bigint,
   employeeid int
) distributed randomly; 

create table pilots_encrypted(
   name bytea,
   license int,
   employeeid int)
distributed randomly;
