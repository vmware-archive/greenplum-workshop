 gpload -v -f gpload.yaml -l gpload.log
 gpload -v -f gpload_encrypt.yaml -l gpload_encrypted.log
