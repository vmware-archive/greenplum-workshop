select get_file_info(current_schema(), 'pilots') plain_text;
select get_file_info(current_schema(), 'pilots_encrypted') encrypted ;
