for x in `cat files_to_check.txt`
do
   echo $x
   sudo -i -u gpadmin ls -alt $x
   sudo -i -u gpadmin strings $x | head
done

