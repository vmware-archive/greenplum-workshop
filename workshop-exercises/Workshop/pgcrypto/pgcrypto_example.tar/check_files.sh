 strings /gpdata/segments/gpseg0/base/37637/63962
 strings /gpdata/segments/gpseg0/base/37637/64003
