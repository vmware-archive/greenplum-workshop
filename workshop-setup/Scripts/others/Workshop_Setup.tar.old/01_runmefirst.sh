#!/bin/bash

# Allow the gpadmin user to access this directory
chmod -R  a+rx $HOME

