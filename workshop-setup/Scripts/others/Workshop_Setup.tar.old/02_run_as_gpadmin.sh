#!/bin/bash -l

PGHBA=$MASTER_DATA_DIRECTORY/pg_hba.conf
cp ${PGHBA} ${PGHBA}.SAVED

egrep -q 'host[[:space:]]+all[[:space:]]+all[[:space:]]+0.0.0.0/0[[:space:]]+trust' ${PGHBA} > /dev/null 2>&1
if [ $? -ne 0 ]; then
cat << _EOF >> ${PGHBA}
##### Entries below added by GPDB or HDB workshop ######
local   all    gpuser                trust
host    all    all      0.0.0.0/0    trust
_EOF
fi
unset PGDATABASE
unset PGUSER
echo "Is GPDB running?"
gpstate -b > /dev/null 2>&1
if [ $? -ne 0 ] ; then
   echo "Starting GPDB"
   gpstart -a
   if [ $? -ne 0 ] ; then
      echo "Problems starting GPDB. Exiting."
      exit 1
   fi
else
   gpstop -u
fi

# Add the gpuser role to the db if it doesn't already exist
psql -d postgres -c '\du'| grep gpuser 
if [ $? -ne 0 ] ; then

  echo "Creating gpuser"
  echo "NOTE: Set password to pivotal"
  createuser --echo --pwprompt --no-superuser --no-createrole --createdb --login --inherit gpuser
fi

# Create the gpuser DB if it doesn't already exist
psql -d postgres -c '\l'| grep gpuser
if [ $? -ne 0 ] ; then
  echo "Creating gpuser database"
  psql -d postgres -c "create database gpuser;"
fi

psql -d gpuser -c "alter database gpuser owner to gpuser;"
psql -d gpuser -c "alter role gpuser createexttable;"
psql -d gpuser -c "grant all privileges on schema madlib to gpuser;"
