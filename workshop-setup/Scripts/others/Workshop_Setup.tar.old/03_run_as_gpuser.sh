#!/bin/bash -l

##set -o errexit

PSQLRC="$HOME/.psqlrc"
if [ ! -f $PSQLRC ]
then
cat << _CMDS_ > $PSQLRC
\pset null NULL
\timing on
\set ECHO all
set search_path = faa, madlib, pg_catalog, gp_toolkit, public;
_CMDS_
fi

psql -d gpuser -c 'drop schema if exists faa cascade;'
psql -d gpuser -c 'create schema faa;'
