# Set the Exercise directory based on the location of execution
export HD=$(pwd | sed  's?/gpuser.*?gpuser/Exercises?')

set -o errexit

echo "This script will drop the existing \'faa\' schema if it exists."
read -n 1 -p "Proceed [y|N]? " ans

if [ $ans = "n" ] || [ $ans = "N" ] || [ "x$ans" = "x" ]
then
    echo Exiting ...
    exit 0
fi

psql -c 'drop schema if exists faa cascade'
psql -c 'create schema faa' || { echo Problem with creating the \'faa\' schema; exit 1; }
