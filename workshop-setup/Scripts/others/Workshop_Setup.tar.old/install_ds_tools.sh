# Install Zeppelin

if [ ! -d /opt/pivotal/zeppelin-0.7.3-bin-all ]; then
    pushd /opt/pivotal/greenplum/optional/pkg

    wget http://apache.claz.org/zeppelin/zeppelin-0.7.3/zeppelin-0.7.3-bin-all.tgz
    tar -xvz -C /opt/pivotal -f /data4/pkg/zeppelin-0.7.3-bin-all.tgz 
    ln -s /opt/pivotal/zeppelin-0.7.3-bin-all /opt/pivotal/zeppelin
    echo 'alias zeppelin=/opt/pivotal/zeppelin/bin/zeppelin.sh' >> ~/.bashrc
    alias zeppelin=/opt/pivotal/zeppelin/bin/zeppelin.sh
    zeppelin start

    echo #################################################################
    echo NOTE: Zeppelin is running on port 8080. Make sure you can access
    echo       this port from your client.
    echo #################################################################

    popd
fi

# Install Jupyter
if [ ! -f /usr/local/greenplum-db/ext/python/bin/jupyter ]; then
    export LIBRARY_PATH=$LD_LIBRARY_PATH
    python -m pip install jupyter
fi
