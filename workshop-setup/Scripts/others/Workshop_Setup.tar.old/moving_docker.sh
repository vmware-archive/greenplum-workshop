#
# Move the /var/lib/docker directory to another location to ease the disk space
# crunch on the root volume.
#

NEWDIR=/data4/var-lib-docker

sudo mkdir -p $NEWDIR
sudo chown root:root $NEWDIR
sudo chmod 700 $NEWDIR

sudo docker stop $(docker ps -q)
sudo service docker stop

# Make a backup in case something screws up
tar -zcC /var/lib docker > /data3/var_lib_docker-backup-$(date +%s).tar.gz

mv /var/lib/docker/* $NEWDIR
ln -s $NEWDIR /var/lib/docker

sudo service docker start
