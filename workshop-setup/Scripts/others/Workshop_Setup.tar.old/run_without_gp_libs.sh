#!/bin/bash

unset LD_LIBRARY_PATH
unset PYTHONHOME
unset PYTHONPATH

PATH=/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/usr/local/bin:/opt/pivotal/zeppelin/bin:/home/gpadmin/bin

$@
