#!/bin/bash
# Script to upgrade the current GP 5.x cluster to 5.(x+n)


echo_run()
{
    echo $1
    eval $1
    return $?
}

get_cmdline_opts()
{
    usage=$(cat << EOF
Usage: $0 -u <new GP tar file> -y
\nWhere: -u <file> is the new installer downloaded from Pivotal Network
\n\t -y  assume yes (don't prompt for confirmation)
EOF
)

	# Parse command line args
	while getopts ":u:y" opt; do
	  case "${opt}" in
	       u) INSTALL_TAR=$OPTARG
              ;;
	       y) NO_CONFIRMATION=1
              ;;
	       *) echo -e $usage
		      exit 1
              ;;
	  esac
	done

    [[ ! -f $INSTALL_TAR ]] && { echo -e $usage ; return 1 ; }
    shift $((OPTIND-1))
    return 0
}

if get_cmdline_opts; then
    shutdown_gp
    install_gp $INSTALL_TAR
    migrate_pkgs
else
    exit 1
fi
